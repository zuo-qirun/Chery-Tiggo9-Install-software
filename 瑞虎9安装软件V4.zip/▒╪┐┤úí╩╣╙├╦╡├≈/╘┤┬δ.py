import os, easygui
print("---------------初始化---------------")
loop = True
os.system("adb start-server")

while loop:
    print("选择要上传的文件")
    path = easygui.fileopenbox("选择安装包", "选择安装包", '*.apk')
    print(path)
    
    
    filename = input("是否更改文件名? 文件名不能含有中文或空格!! 若含有请在此处输入新文件名 若无请点击回车键跳过此流程")
    if filename == "":
        filename = os.path.basename(path)
    elif len(filename) <= 4 or filename[-4:] != ".apk":
        filename = filename + ".apk"
    print(filename)
    if os.system("adb push \"" + path + "\" \"/data/local/tmp/" + filename + "\""):
        print("\033[1;31m上传失败，请截图并联系作者\033[0m")
    
        
    print("---------------正在安装---------------")
    if os.system("adb shell pm install -g \"/data/local/tmp/" + filename + "\""):
        print("\033[1;31m安装失败，请截图并联系作者\033[0m")
    else:
        print("---------------安装完成---------------")
        
        
    ans = input("是否清除缓存(这段代码没测试过)(Y/N, defult: N):")
    if ans == 'Y' or ans == 'y':
        if os.system("adb shell rm -rf /data/local/tmp/*"): #应该没写错吧......
            print("\033[1;31m清除失败，请截图并联系作者\033[0m")
        print("清除成功")
        
        
    loopans = input("是否继续安装软件? (Y/N, defult: N):")
    loop = True if loopans == 'Y' or loopans == 'N' else False
os.system("pause")