import os, easygui
print("---------------初始化---------------")
os.system("adb start-server")
print("选择要上传的文件")
path = easygui.fileopenbox("选择安装包", "选择安装包", '*.apk')
print(path)
filename = os.path.basename(path)
if os.system("adb push \"" + path + "\" /data/local/tmp"):
    print("\033[1;31m上传失败，请截图并联系作者\033[0m")
print("---------------正在安装---------------")
if os.system("adb shell pm install -g /data/local/tmp/" + filename):
    print("\033[1;31m安装失败，请截图并联系作者\033[0m")
else:
    print("---------------安装完成---------------")
ans = input("是否清除缓存(这段代码没测试过)(Y/N, defult: N):")
if ans == 'Y' or ans == 'y':
    if os.system("adb shell rm -rf /data/local/tmp/*"): #应该没写错吧......
        print("\033[1;31m清除失败，请截图并联系作者\033[0m")
    print("清除成功")
os.system("pause")